﻿namespace EagleEye_API.Models
{
    public class Stats
    {
        public int MovieId { get; set; }
        public double Duration { get; set; }
    }
}
