﻿using CsvHelper;
using EagleEye_API.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EagleEye_API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class MetadataController : ControllerBase
    {
        // GET api/<MetadataController>/5
        [HttpGet("{movieId}")]
        public IActionResult Get(int movieId)
        {
            const string docPath = "AppData/metadata.csv";

            //read data from file where movie id matches
            if (System.IO.File.Exists(docPath))
            {
                var config = new CsvHelper.Configuration.CsvConfiguration(System.Globalization.CultureInfo.InvariantCulture)
                {
                    Delimiter = ",",
                    MissingFieldFound = null,
                    TrimOptions = CsvHelper.Configuration.TrimOptions.Trim,
                    HeaderValidated = null,
                    ShouldSkipRecord = (record) =>
                    {
                        if (record.Record.Count() != 6)
                            return true;
                        
                        return record.Record.Any(field => string.IsNullOrEmpty(field));
                    }
                };

                using (var reader = new System.IO.StreamReader(docPath))
                {
                    using (var csv = new CsvReader(reader, config))
                    {
                        List<Metadata> records = new List<Metadata>();
                        bool headerRead = false;

                        while (csv.Read())
                        {
                            if(!headerRead)
                            {
                                headerRead = true;
                                continue;
                            }

                            int mId, ry;
                            if (!Int32.TryParse(csv.GetField(1), out mId) ||
                                !Int32.TryParse(csv.GetField(5), out ry))
                                continue;

                            records.Add(new Metadata
                            {
                                Id = csv.GetField(0),
                                MovieId = mId,
                                Title = csv.GetField(2),
                                Language = csv.GetField(3),
                                Duration = csv.GetField(4),
                                ReleaseYear = ry
                            });
                        }

                        var result = (from r in records
                                   group r by (r.Language, r.MovieId) into grp
                                   orderby grp.Key.MovieId
                                   where grp.Key.MovieId == movieId
                                   select grp.OrderByDescending(x => x.Id).FirstOrDefault())
                                   .OrderBy(x=>x.Language).ToList();

                        if (result.Count > 0)
                            return Ok(result);
                        else
                            return NotFound();
                    }
                }
            }

            return BadRequest();
        }

        /// <summary>
        /// Adds the metadata to the 'database' file
        /// </summary>
        /// <param name="metadata"></param>
        /// <returns></returns>
        // POST api/<MetadataController>
        [HttpPost]
        public IActionResult Post([FromBody] Metadata metadata)
        {
            SaveMetaData(metadata);
            return CreatedAtAction("Get", metadata);
        }


        /// <summary>
        /// Basic method to add metadata to AppData/database.txt
        /// </summary>
        /// <param name="metadata"></param>
        /// <returns></returns>
        private void SaveMetaData(Metadata metadata)
        {
            const string docPath = "AppData/database.txt";
            int lineCount = 1;

            //Get number of lines in text file (used to generate an index/ID value)
            if (System.IO.File.Exists(docPath))
            {
                using (System.IO.StreamReader inputfile = new System.IO.StreamReader(docPath))
                {
                    while (inputfile.ReadLine() != null)
                    {
                        lineCount++;
                    }
                }
            }

            //Save to text file
            using (System.IO.StreamWriter outputFile = new System.IO.StreamWriter(docPath, true))
            {
                outputFile.WriteLine(
                    lineCount + "," +
                    metadata.MovieId + "," +
                    metadata.Title + "," +
                    metadata.Language + "," +
                    metadata.Duration + "," +
                    metadata.ReleaseYear);
            }
        }
    }
}
