﻿using CsvHelper;
using EagleEye_API.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EagleEye_API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        // GET: api/<MoviesController>
        [Route("stats")]
        [HttpGet]
        public IActionResult Get()
        {
            //Load data files
            List<Metadata> records = LoadMetadata();
            List<Stats> stats = LoadStats();

            List<MovieStat> movieStats = new List<MovieStat>();

            //Get latest movie entry for data
            var gr = from r in records
                     group r by (r.MovieId) into grp
                     select grp.OrderByDescending(x=>x.Id).FirstOrDefault();

            //Get movie stats
            foreach(var movie in gr)
            {
                //get stats and add to results collection
                int watches = stats.Where(x => x.MovieId == movie.MovieId).Count();
                double duration = stats.Where(x => x.MovieId == movie.MovieId).Average(x => x.Duration) / 60;

                movieStats.Add(new MovieStat
                {
                    movieId = movie.MovieId,
                    title = movie.Title,
                    averageWatchDurationS = (int)duration,
                    watches = watches,
                    releaseYear = movie.ReleaseYear
                });
            }

            return Ok(movieStats.OrderByDescending(x => (x.watches, x.releaseYear)));
        }


        //usually add as service but for test - function will do
        private List<Metadata> LoadMetadata()
        {
            const string docPath = "AppData/metadata.csv";
            List<Metadata> records = new List<Metadata>();

            //read file
            if (System.IO.File.Exists(docPath))
            {
                var config = new CsvHelper.Configuration.CsvConfiguration(System.Globalization.CultureInfo.InvariantCulture)
                {
                    Delimiter = ",",
                    MissingFieldFound = null,
                    TrimOptions = CsvHelper.Configuration.TrimOptions.Trim,
                    HeaderValidated = null,
                    ShouldSkipRecord = (record) =>
                    {
                        if (record.Record.Count() != 6)
                            return true;

                        return record.Record.Any(field => string.IsNullOrEmpty(field));
                    }
                };

                using (var reader = new System.IO.StreamReader(docPath))
                {
                    using (var csv = new CsvReader(reader, config))
                    {
                        bool headerRead = false;

                        while (csv.Read())
                        {
                            if (!headerRead)
                            {
                                headerRead = true;
                                continue;
                            }

                            int mId, ry;
                            if (!Int32.TryParse(csv.GetField(1), out mId) ||
                                !Int32.TryParse(csv.GetField(5), out ry))
                                continue;

                            records.Add(new Metadata
                            {
                                Id = csv.GetField(0),
                                MovieId = mId,
                                Title = csv.GetField(2),
                                Language = csv.GetField(3),
                                Duration = csv.GetField(4),
                                ReleaseYear = ry
                            });
                        }
                    }
                }
            }
            return records;
        }

        private List<Stats> LoadStats()
        {
            const string docPath = "AppData/stats.csv";
            List<Stats> records = new List<Stats>();

            //read file
            if (System.IO.File.Exists(docPath))
            {
                var config = new CsvHelper.Configuration.CsvConfiguration(System.Globalization.CultureInfo.InvariantCulture)
                {
                    Delimiter = ",",
                    MissingFieldFound = null,
                    TrimOptions = CsvHelper.Configuration.TrimOptions.Trim,
                    HeaderValidated = null,
                    ShouldSkipRecord = (record) =>
                    {
                        if (record.Record.Count() != 2)
                            return true;

                        return record.Record.Any(field => string.IsNullOrEmpty(field));
                    }
                };

                using (var reader = new System.IO.StreamReader(docPath))
                {
                    using (var csv = new CsvReader(reader, config))
                    {
                        bool headerRead = false;

                        while (csv.Read())
                        {
                            if (!headerRead)
                            {
                                headerRead = true;
                                continue;
                            }

                            int mId;
                            double dur;

                            if (!Int32.TryParse(csv.GetField(0), out mId) ||
                                !Double.TryParse(csv.GetField(1), out dur))
                                continue;

                            records.Add(new Stats
                            {
                                MovieId = mId,
                                Duration = dur
                            });
                        }
                    }
                }
            }
            return records;
        }

    }
}
